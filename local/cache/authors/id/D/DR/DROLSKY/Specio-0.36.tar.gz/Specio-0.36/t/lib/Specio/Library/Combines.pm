package Specio::Library::Combines;

use strict;
use warnings;

use parent 'Specio::Exporter';

use Specio::Library::Builtins -reexport;
use Specio::Library::XY -reexport;

1;
