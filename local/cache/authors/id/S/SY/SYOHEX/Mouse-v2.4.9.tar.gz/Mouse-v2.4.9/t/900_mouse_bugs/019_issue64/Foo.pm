package Foo;
use Mouse;
extends 'Bar';

has '+attr_0'  => (
    isa => 'Num',
);

1;
